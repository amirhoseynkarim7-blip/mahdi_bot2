import json
import math
import os
import time
import tkinter as tk
from tkinter import filedialog, messagebox, font as tkFont
from PIL import Image, ImageTk, ImageDraw, ImageSequence
import random
import pygame
from mutagen.mp3 import MP3
from mutagen.wave import WAVE
from mutagen.oggvorbis import OggVorbis

# ==================== CONFIGURATION ====================
FAVORITES_FILE = 'favorites.json'
GIFS = {
    'happy': 'happy.gif',
    'sad': 'sad.gif',
    'gang': 'gang.gif',
}

PALETTE = {
    'bg': '#fff0f5',           # Light pink background
    'card': '#ffffff',         # White card
    'accent': '#ff85a2',       # Cute pink accent
    'accent_dark': '#ff4785',  # Darker pink
    'accent_light': '#ffb8c9', # Light pink
    'text': '#8a5a7d',         # Purple text
    'muted': '#c4a8bf',        # Muted purple
    'gold': '#ffd700',         # Gold for favorites
    'progress_bg': '#ffe8f1',  # Progress bar background
    'hover': '#ffd6e6',        # Hover effect
    'shadow': '#ffccdd',       # Soft shadow
    'sparkle': '#fffacd',      # Sparkle color
    'heart': '#ff2a70',        # Heart color for about button
    'heart_hover': '#ff4785',  # Heart hover color
}

WINDOW_WIDTH = 800
WINDOW_HEIGHT = 600

# ==================== UTILITY FUNCTIONS ====================
def create_round_rect(canvas, x1, y1, x2, y2, r, **kwargs):
    points = [x1+r, y1, x2-r, y1, x2, y1, x2, y1+r,
              x2, y2-r, x2, y2, x2-r, y2, x1+r, y2,
              x1, y2, x1, y2-r, x1, y1+r, x1, y1]
    return canvas.create_polygon(points, smooth=True, **kwargs)

tk.Canvas.create_round_rect = create_round_rect

def get_audio_duration(path):
    try:
        if path.endswith('.mp3'):
            audio = MP3(path)
        elif path.endswith('.wav'):
            audio = WAVE(path)
        elif path.endswith('.ogg'):
            audio = OggVorbis(path)
        else:
            return 0
        return audio.info.length
    except:
        return 0

# ==================== FLOATING BUBBLES ====================
class FloatingBubbles:
    def __init__(self, canvas):
        self.canvas = canvas
        self.bubbles = []
        self.colors = ['#ffccdd', '#ffd6e6', '#ffe6ee', '#fff0f5']
        
    def create_bubbles(self, count=10):
        for _ in range(count):
            x = random.randint(0, WINDOW_WIDTH)
            y = random.randint(0, WINDOW_HEIGHT)
            size = random.randint(5, 20)
            color = random.choice(self.colors)
            speed = random.uniform(0.2, 0.8)
            
            bubble = self.canvas.create_oval(x, y, x+size, y+size, 
                                           fill=color, outline='', tags='bubble')
            self.bubbles.append({
                'id': bubble,
                'speed': speed,
                'size': size
            })
    
    def animate(self):
        for bubble in self.bubbles:
            self.canvas.move(bubble['id'], 0, -bubble['speed'])
            x1, y1, x2, y2 = self.canvas.coords(bubble['id'])
            
            if y2 < 0:
                self.canvas.coords(bubble['id'], 
                                  random.randint(0, WINDOW_WIDTH),
                                  WINDOW_HEIGHT + 10,
                                  random.randint(0, WINDOW_WIDTH) + bubble['size'],
                                  WINDOW_HEIGHT + 10 + bubble['size'])
        
        self.canvas.after(50, self.animate)

# ==================== SUPER CUTE ABOUT BUTTON ====================
class UltraCuteAboutButton(tk.Canvas):
    def __init__(self, master, command=None, size=40, **kwargs):
        super().__init__(master, width=size, height=size, 
                        highlightthickness=0, bg=PALETTE['bg'])
        self.command = command
        self.size = size
        self.is_hovered = False
        self.pulse_scale = 1.0
        self.pulse_dir = 0.01
        
        self.bind('<Enter>', self.on_enter)
        self.bind('<Leave>', self.on_leave)
        self.bind('<Button-1>', self.on_click)
        self.config(cursor='hand2')
        
        self.draw_button()
        self.start_pulse()
    
    def draw_button(self):
        self.delete('all')
        center = self.size // 2
        size = int(self.size * 0.7 * self.pulse_scale)
        
        color = PALETTE['heart_hover'] if self.is_hovered else PALETTE['heart']
            
        points = []
        for t in range(0, 360, 5):
            t_rad = math.radians(t)
            x = center + 16 * math.sin(t_rad)**3 * (size/40)
            y = center - (13 * math.cos(t_rad) - 5 * math.cos(2*t_rad) - 
                          2 * math.cos(3*t_rad) - math.cos(4*t_rad)) * (size/40)
            points.extend([x, y])
        
        self.create_polygon(points, fill=color, outline=PALETTE['accent_light'], width=2, smooth=True)
        self.create_text(center, center, text="?", font=('Comic Sans MS', 12, 'bold'), fill='white')
    
    def start_pulse(self):
        self.pulse_scale += self.pulse_dir
        if self.pulse_scale > 1.05:
            self.pulse_dir = -0.01
        elif self.pulse_scale < 0.95:
            self.pulse_dir = 0.01
            
        self.draw_button()
        self.after(50, self.start_pulse)
    
    def on_enter(self, event):
        self.is_hovered = True
        self.draw_button()
    
    def on_leave(self, event):
        self.is_hovered = False
        self.draw_button()
    
    def on_click(self, event):
        if self.command:
            self.command()

# ==================== SUPER CUTE ANIMATED GIF ====================
class SuperCuteAnimatedGif(tk.Label):
    def __init__(self, master, path=None, size=(220, 220), **kw):
        super().__init__(master, **kw)
        self.path = path
        self.size = size
        self.frames = []
        self.delay = 80
        self._after = None
        self._idx = 0
        self._load()

    def _load(self):
        self.frames.clear()
        self._idx = 0
        
        if self.path and os.path.exists(self.path):
            im = Image.open(self.path)
            self.delay = im.info.get('duration', 80)
            for frame in ImageSequence.Iterator(im):
                frame = frame.convert('RGBA').resize(self.size, Image.LANCZOS)
                mask = Image.new('L', self.size, 0)
                draw = ImageDraw.Draw(mask)
                draw.ellipse((0, 0, self.size[0], self.size[1]), fill=255)
                
                result = Image.new('RGBA', self.size, (0, 0, 0, 0))
                result.paste(frame, (0, 0), mask)
                result_with_border = self._add_cute_effects(result)
                self.frames.append(ImageTk.PhotoImage(result_with_border))
        else:
            for i in range(3):
                ph = Image.new('RGBA', self.size, (0, 0, 0, 0))
                d = ImageDraw.Draw(ph)
                w, h = self.size
                
                for r in range(w//2, 0, -2):
                    alpha = int(100 * (r / (w/2)))
                    d.ellipse((w//2-r, h//2-r, w//2+r, h//2+r), fill=f'#ffc2d6{alpha:02x}', outline='')
                
                d.ellipse((w*0.2, h*0.2, w*0.8, h*0.8), fill='#ffe6ee', outline=PALETTE['accent'], width=4)
                eye_size = w * 0.15
                d.ellipse((w*0.3, h*0.4, w*0.3+eye_size, h*0.4+eye_size), fill=PALETTE['accent_dark'])
                d.ellipse((w*0.7-eye_size, h*0.4, w*0.7, h*0.4+eye_size), fill=PALETTE['accent_dark'])
                
                sparkle_pos = [(w*0.33, h*0.43), (w*0.67, h*0.43)][i % 2]
                d.ellipse((sparkle_pos[0], sparkle_pos[1], sparkle_pos[0]+5, sparkle_pos[1]+5), fill='white')
                
                d.ellipse((w*0.2, h*0.5, w*0.25, h*0.55), fill='#ff9ecb88')
                d.ellipse((w*0.75, h*0.5, w*0.8, h*0.55), fill='#ff9ecb88')
                
                smile_start = 180 if i % 2 == 0 else 190
                d.arc((w*0.35, h*0.55, w*0.65, h*0.7), smile_start, 360, fill=PALETTE['accent_dark'], width=3)
                self.frames.append(ImageTk.PhotoImage(ph))
            self.delay = 300
        
        if self.frames:
            self.config(image=self.frames[0])

    def _add_cute_effects(self, image):
        draw = ImageDraw.Draw(image)
        w, h = self.size
        draw.ellipse((0, 0, w-1, h-1), outline=PALETTE['accent'], width=6)
        
        for angle in range(0, 360, 30):
            rad = math.radians(angle)
            x = w//2 + (w//2 - 10) * math.cos(rad)
            y = h//2 + (h//2 - 10) * math.sin(rad)
            draw.ellipse((x-3, y-3, x+3, y+3), fill=PALETTE['sparkle'])
        return image

    def set_gif(self, path):
        self.path = path
        self._load()

    def play(self):
        if not self.frames: return
        self.stop()
        self._loop()

    def _loop(self):
        if not self.frames: return
        self.config(image=self.frames[self._idx])
        self._idx = (self._idx + 1) % len(self.frames)
        self._after = self.after(self.delay, self._loop)

    def stop(self):
        if self._after:
            self.after_cancel(self._after)
            self._after = None

# ==================== ULTRA CUTE BUTTON ====================
class UltraCuteButton(tk.Canvas):
    def __init__(self, master, text, command=None, width=100, height=45, emoji="", **kwargs):
        super().__init__(master, width=width, height=height, highlightthickness=0, bg=PALETTE['bg'])
        self.command = command
        self.text = text
        self.emoji = emoji
        self.width = width
        self.height = height
        self.is_hovered = False
        self.is_pressed = False
        self.y_offset = 0
        
        self.bind('<Enter>', self.on_enter)
        self.bind('<Leave>', self.on_leave)
        self.bind('<Button-1>', self.on_press)
        self.bind('<ButtonRelease-1>', self.on_release)
        self.config(cursor='hand2')
        
        self.draw_button()
        self.start_floating()
    
    def set_text(self, new_text):
        self.text = new_text
        self.draw_button()

    def draw_button(self):
        self.delete('all')
        y_pos = 2 + self.y_offset
        
        if self.is_pressed:
            fill_color = PALETTE['accent_dark']
            text_color = 'white'
            y_pos = 4
        elif self.is_hovered:
            fill_color = PALETTE['accent']
            text_color = 'white'
        else:
            fill_color = PALETTE['card']
            text_color = PALETTE['accent_dark']
        
        self.create_round_rect(4, 4+y_pos, self.width-2, self.height-2+y_pos, 15, fill=PALETTE['shadow'], outline='')
        self.create_round_rect(2, 2+y_pos, self.width-4, self.height-4+y_pos, 15, fill=fill_color, outline=PALETTE['accent_light'], width=2)
        
        full_text = f"{self.emoji} {self.text}" if self.emoji else self.text
        self.create_text(self.width//2, self.height//2 + y_pos, text=full_text, fill=text_color, font=('Comic Sans MS', 10, 'bold'))
    
    def start_floating(self):
        self.y_offset = math.sin(time.time() * 3) * 1.5
        self.draw_button()
        self.after(50, self.start_floating)
    
    def on_enter(self, event):
        self.is_hovered = True
        self.draw_button()
    
    def on_leave(self, event):
        self.is_hovered = False
        self.is_pressed = False
        self.draw_button()
    
    def on_press(self, event):
        self.is_pressed = True
        self.draw_button()
    
    def on_release(self, event):
        self.is_pressed = False
        self.draw_button()
        if self.command: self.command()

# ==================== CUTE FAVORITES WINDOW ====================
class CuteFavoritesWindow(tk.Toplevel):
    def __init__(self, parent, favorites_list, play_callback):
        super().__init__(parent)
        self.title('💖 My Playlist 💖')
        self.geometry('500x400')
        self.configure(bg=PALETTE['bg'])
        self.resizable(False, False)
        
        self.favorites_list = favorites_list  
        self.play_callback = play_callback
        self.cute_font = tkFont.Font(family="Comic Sans MS", size=11)
        
        self.center_window()
        self._build_ui()
    
    def center_window(self):
        self.update_idletasks()
        x = (self.winfo_screenwidth() // 2) - (500 // 2)
        y = (self.winfo_screenheight() // 2) - (400 // 2)
        self.geometry(f'500x400+{x}+{y}')
    
    def _build_ui(self):
        title_label = tk.Label(self, text='💖 My Cute Playlist 💖', font=('Comic Sans MS', 16, 'bold'), bg=PALETTE['bg'], fg=PALETTE['accent_dark'])
        title_label.pack(pady=15)
        
        list_frame = tk.Frame(self, bg=PALETTE['bg'])
        list_frame.pack(pady=10, padx=20, fill='both', expand=True)
        
        self.listbox = tk.Listbox(list_frame, bg=PALETTE['card'], fg=PALETTE['text'], selectbackground=PALETTE['accent'], font=self.cute_font, highlightthickness=0, bd=0)
        scrollbar = tk.Scrollbar(list_frame, orient='vertical', command=self.listbox.yview)
        self.listbox.configure(yscrollcommand=scrollbar.set)
        
        self.listbox.pack(side='left', fill='both', expand=True, padx=(0, 5))
        scrollbar.pack(side='right', fill='y')
        
        for song_path in self.favorites_list:
            song_name = os.path.basename(song_path)
            self.listbox.insert('end', f"🎵 {song_name}")
        
        btn_frame = tk.Frame(self, bg=PALETTE['bg'])
        btn_frame.pack(pady=15)
        
        UltraCuteButton(btn_frame, 'Play', self.play_selected, width=100, height=40, emoji='▶').pack(side='left', padx=10)
        UltraCuteButton(btn_frame, 'Close', self.destroy, width=100, height=40, emoji='❌').pack(side='left', padx=10)
    
    def play_selected(self):
        selection = self.listbox.curselection()
        if not selection:
            messagebox.showinfo('💖', 'Please select a song first!')
            return
        
        selected_index = selection[0]
        selected_song = self.favorites_list[selected_index] 
        self.play_callback(selected_song)
        self.destroy()

# ==================== MAIN APPLICATION ====================
class UltraCuteMusicPlayer(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('🐰✨ Ultra Cute Music Player 🌸🎵')
        self.geometry(f'{WINDOW_WIDTH}x{WINDOW_HEIGHT}')
        self.configure(bg=PALETTE['bg'])
        self.resizable(False, False)
        
        self.center_window()
        pygame.mixer.init()
        
        self.current_song = None
        self.song_length = 0
        self.playing = False
        self.play_start_time = 0.0
        self.start_offset = 0.0
        self.song_ended = False
        self.repeat_mode = False

        self.favorites = self.load_favorites()
        self.playlist = sorted(list(self.favorites)) 
        
        self.cute_font = tkFont.Font(family="Comic Sans MS", size=11)
        self.title_font = tkFont.Font(family="Comic Sans MS", size=18, weight="bold")
        
        self._build_ui()
        self._update_progress_loop()
        self._update_time_display()
        self._check_song_end()

    def center_window(self):
        self.update_idletasks()
        x = (self.winfo_screenwidth() // 2) - (WINDOW_WIDTH // 2)
        y = (self.winfo_screenheight() // 2) - (WINDOW_HEIGHT // 2)
        self.geometry(f'{WINDOW_WIDTH}x{WINDOW_HEIGHT}+{x}+{y}')

    def show_about(self):
        about_text = "Designed by Amir Hossein Karim, 14 years old from Semnan city. Presented with love! 💖"
        messagebox.showinfo('About 🌸', about_text)

    def _build_ui(self):
        self.bg_canvas = tk.Canvas(self, width=WINDOW_WIDTH, height=WINDOW_HEIGHT, bg=PALETTE['bg'], highlightthickness=0)
        self.bg_canvas.place(x=0, y=0)
        
        self.bubbles = FloatingBubbles(self.bg_canvas)
        self.bubbles.create_bubbles(15)
        self.bubbles.animate()

        self.about_button = UltraCuteAboutButton(self, command=self.show_about, size=40)
        self.about_button.place(x=10, y=10)

        title_label = tk.Label(self, text='🌸 Ultra Cute Music Player 🌸', font=self.title_font, bg=PALETTE['bg'], fg=PALETTE['accent_dark'])
        title_label.place(x=WINDOW_WIDTH//2, y=20, anchor='center')

        main_frame = tk.Frame(self, bg=PALETTE['bg'])
        main_frame.place(x=20, y=60, width=760, height=500)

        self.left_disc_img = None
        self.left_disc_angle = 0
        self.left_disc_canvas = tk.Canvas(main_frame, width=240, height=240, bg=PALETTE['bg'], highlightthickness=0)
        self.left_disc_canvas.place(x=20, y=20)
        self._draw_left_disc()

        self.right_knob_img = None
        self.right_knob_angle = 0  
        self.right_knob_canvas = tk.Canvas(main_frame, width=240, height=240, bg=PALETTE['bg'], highlightthickness=0)
        self.right_knob_canvas.place(x=500, y=20)
        self.right_knob_canvas.bind('<Button-1>', self._vol_begin)
        self.right_knob_canvas.bind('<B1-Motion>', self._vol_drag)
        self.right_knob_canvas.config(cursor='hand2')
        self._draw_right_knob()

        self.vol_label = tk.Label(main_frame, text='🔊 Volume: 50%', bg=PALETTE['bg'], fg=PALETTE['text'], font=self.cute_font)
        self.vol_label.place(x=560, y=270)

        self.gif = SuperCuteAnimatedGif(main_frame, path=self._gif_path('happy'), size=(240, 240), bg=PALETTE['bg'])
        self.gif.place(x=260, y=20)
        self.gif.play()
        self.gif.bind('<Button-1>', lambda e: self.toggle_play())
        self.gif.config(cursor='hand2')

        moods = [('😺 Happy', 'happy'), ('😢 Sad', 'sad'), ('😎 Cool', 'gang')]
        for i, (text, mood_val) in enumerate(moods):
            btn = UltraCuteButton(main_frame, text, command=lambda v=mood_val: self.set_mood(v), width=80, height=40)
            btn.place(x=260 + i*90, y=280)

        self.progress = tk.DoubleVar(value=0.0)
        self.progress_bar = tk.Canvas(main_frame, width=500, height=18, bg=PALETTE['bg'], highlightthickness=0)
        self.progress_bar.place(x=130, y=340)
        self.progress_bar.bind('<Button-1>', self._click_seek)
        self.progress_bar.config(cursor='hand2')
        self._draw_progress()

        # تک دکمه شدن پلی/پوز با جایگذاری بهینه‌شده
        self.play_btn = UltraCuteButton(main_frame, "Play", self.toggle_play, width=95, height=40, emoji="▶")
        self.play_btn.place(x=140, y=380)

        controls = [
            ('⏪ 5s', lambda: self.jump(-5), 250),
            ('5s ⏩', lambda: self.jump(5), 345),
            ('🔂 Loop', self.toggle_repeat, 440),
            ('⭐ Fav', self.toggle_favorite, 535),
            ('💖 List', self.show_favorites, 630)
        ]
        
        for text, command, x_pos in controls:
            btn = UltraCuteButton(main_frame, text, command, width=80, height=40)
            btn.place(x=x_pos, y=380)

        self.song_label = tk.Label(main_frame, text='🎵 Click here to open a song! 🎵', bg=PALETTE['bg'], fg=PALETTE['muted'], font=self.cute_font, cursor='hand2')
        self.song_label.place(x=130, y=440)
        self.song_label.bind('<Button-1>', lambda e: self.open_song())

        self.time_label = tk.Label(main_frame, text='⏰ 00:00 / 00:00', bg=PALETTE['bg'], fg=PALETTE['muted'], font=self.cute_font)
        self.time_label.place(x=130, y=470)

        self.bind('<space>', lambda e: self.toggle_play())
        self.bind('<Left>', lambda e: self.jump(-5))
        self.bind('<Right>', lambda e: self.jump(5))
        self.bind('<Up>', lambda e: self._nudge_volume(+0.1))
        self.bind('<Down>', lambda e: self._nudge_volume(-0.1))
        self.bind('<Control-o>', lambda e: self.open_song())

        self._spin_left_disc()

    def _draw_left_disc(self):
        img = Image.new('RGBA', (240, 240), (0, 0, 0, 0))
        d = ImageDraw.Draw(img)
        d.ellipse((10, 10, 230, 230), fill='#ffe6ee', outline=PALETTE['accent'], width=6)
        for r in range(50, 100, 8):
            d.ellipse((120-r, 120-r, 120+r, 120+r), outline=PALETTE['accent_light'], width=3)
        d.ellipse((110, 110, 130, 130), fill=PALETTE['accent_dark'])
        d.ellipse((115, 115, 125, 125), fill='white')
        
        img = img.rotate(self.left_disc_angle, resample=Image.BICUBIC, expand=True)
        self.left_disc_img = ImageTk.PhotoImage(img)
        self.left_disc_canvas.delete('all')
        self.left_disc_canvas.create_image(120, 120, image=self.left_disc_img)

    def _draw_right_knob(self):
        img = Image.new('RGBA', (240, 240), (0, 0, 0, 0))
        d = ImageDraw.Draw(img)
        d.ellipse((20, 20, 220, 220), fill='#ffe6ee', outline=PALETTE['accent'], width=6)
        for angle in range(0, 360, 45):
            rad = math.radians(angle)
            x = 120 + 90 * math.cos(rad)
            y = 120 + 90 * math.sin(rad)
            d.ellipse((x-5, y-5, x+5, y+5), fill=PALETTE['accent_dark'])
        
        pointer_angle = math.radians(-self.right_knob_angle)
        x_end = 120 + 80 * math.cos(pointer_angle)
        y_end = 120 + 80 * math.sin(pointer_angle)
        d.line([(120, 120), (x_end, y_end)], fill=PALETTE['accent_dark'], width=8)
        d.ellipse((116, 116, 124, 124), fill=PALETTE['accent_dark'])
        
        self.right_knob_img = ImageTk.PhotoImage(img)
        self.right_knob_canvas.delete('all')
        self.right_knob_canvas.create_image(120, 120, image=self.right_knob_img)

    def _spin_left_disc(self):
        if self.playing:
            self.left_disc_angle = (self.left_disc_angle - 4) % 360
            self._draw_left_disc()
        self.after(30, self._spin_left_disc)

    def _vol_begin(self, event):
        self._vol_drag(event)

    def _vol_drag(self, event):
        x, y = event.x, event.y
        cx, cy = 120, 120 
        angle = math.degrees(math.atan2(cy - y, x - cx))
        adj_angle = (angle + 360) % 360
        
        if adj_angle < 90: adj_angle += 360
        if adj_angle > 405: adj_angle = 405
        elif adj_angle < 135: adj_angle = 135
            
        vol = (adj_angle - 135) / 270.0
        vol = max(0.0, min(1.0, vol))
        
        self.right_knob_angle = angle
        self._draw_right_knob()
        pygame.mixer.music.set_volume(vol)
        self.vol_label.config(text=f'🔊 Volume: {int(vol*100)}%')

    def _nudge_volume(self, dv):
        current_vol = pygame.mixer.music.get_volume()
        new_vol = max(0.0, min(1.0, current_vol + dv))
        pygame.mixer.music.set_volume(new_vol)
        self.right_knob_angle = 135 + (new_vol * 270)
        self._draw_right_knob()
        self.vol_label.config(text=f'🔊 Volume: {int(new_vol*100)}%')

    def set_mood(self, mood):
        self.gif.set_gif(self._gif_path(mood))
        self.gif.play()

    def _gif_path(self, mood):
        return GIFS.get(mood)

    def open_song(self):
        filetypes = [('Audio files', '*.mp3 *.wav *.ogg'), ('All files', '*.*')]
        path = filedialog.askopenfilename(title='Choose a cute song! 🎵', filetypes=filetypes)
        if not path: return
        self.play_target_song(path)

    def play_target_song(self, path):
        try:
            pygame.mixer.music.load(path)
            self.current_song = path
            song_name = os.path.basename(path)
            self.song_label.config(text=f'🎵 {song_name[:25]}...' if len(song_name) > 25 else f'🎵 {song_name}')
            self.song_length = get_audio_duration(path)
            
            self.play_from(0.0)
            self.song_ended = False
            
            self.play_btn.set_text("Pause")
            self.play_btn.emoji = "⏸"
        except Exception as e:
            messagebox.showerror('Oopsie! 🐰', f'Cannot open file:\n{e}')

    def play_from(self, sec):
        try:
            pygame.mixer.music.play(start=sec)
        except:
            pygame.mixer.music.play()
        self.playing = True
        self.play_start_time = time.time()
        self.start_offset = sec
        self.song_ended = False

    def toggle_play(self):
        if not self.current_song:
            self.open_song()
            return
            
        if self.playing:
            pygame.mixer.music.pause()
            self.playing = False
            self.play_btn.set_text("Play")
            self.play_btn.emoji = "▶"
        else:
            pygame.mixer.music.unpause()
            self.playing = True
            self.play_btn.set_text("Pause")
            self.play_btn.emoji = "⏸"
            if pygame.mixer.music.get_pos() == -1:
                self.play_from(self.elapsed())

    def toggle_favorite(self):
        if not self.current_song: return
        if self.current_song in self.favorites:
            self.favorites.remove(self.current_song)
            messagebox.showinfo('⭐', 'Removed from favorites! 😢')
        else:
            self.favorites.add(self.current_song)
            messagebox.showinfo('⭐', 'Added to favorites! 💖')
        self.save_favorites()
        self.playlist = sorted(list(self.favorites)) 

    def toggle_repeat(self):
        self.repeat_mode = not self.repeat_mode
        messagebox.showinfo('🔂', 'Loop Mode On! 🔁' if self.repeat_mode else 'Loop Mode Off! 🎵')

    def show_favorites(self):
        if not self.favorites:
            messagebox.showinfo('💖', 'Your playlist is empty! Add songs using ⭐ button first.')
            return
        CuteFavoritesWindow(self, self.playlist, self.play_target_song)

    def jump(self, delta):
        if not self.current_song: return
        self.play_from(max(0.0, self.elapsed() + delta))

    def elapsed(self):
        pos = pygame.mixer.music.get_pos()
        if pos is not None and pos >= 0:
            return self.start_offset + pos/1000.0
        return self.start_offset if not self.playing else self.start_offset + (time.time() - self.play_start_time)

    def _check_song_end(self):
        if self.playing and self.current_song and self.song_length > 0:
            current_time = self.elapsed()
            
            if current_time >= self.song_length - 0.5 and not self.song_ended:
                if self.repeat_mode:
                    self.play_from(0.0)
                elif self.current_song in self.playlist:
                    current_idx = self.playlist.index(self.current_song)
                    next_idx = (current_idx + 1) % len(self.playlist)
                    next_song = self.playlist[next_idx]
                    self.play_target_song(next_song)
                else:
                    self.song_ended = True
                    self.playing = False
                    self.play_btn.set_text("Play")
                    self.play_btn.emoji = "▶"
                    self.start_offset = 0.0
                    self.progress.set(0.0)
                    self._draw_progress()
                    self.time_label.config(text='⏰ 00:00 / 00:00')
        
        self.after(500, self._check_song_end)

    def _update_time_display(self):
        if self.current_song:
            elapsed_str = time.strftime('%M:%S', time.gmtime(self.elapsed()))
            total_str = time.strftime('%M:%S', time.gmtime(self.song_length)) if self.song_length > 0 else '??:??'
            self.time_label.config(text=f'⏰ {elapsed_str} / {total_str}')
        self.after(200, self._update_time_display)

    def _draw_progress(self):
        c = self.progress_bar
        c.delete('all')
        w, h = 500, 18
        c.create_round_rect(0, 0, w, h, h/2, fill=PALETTE['progress_bg'], outline=PALETTE['accent_light'])
        frac = min(1.0, self.progress.get())
        fillw = max(h, frac * w)
        c.create_round_rect(0, 0, fillw, h, h/2, fill=PALETTE['accent'], outline='')
        if fillw > h:
            c.create_oval(fillw-8, 5, fillw+3, 16, fill=PALETTE['sparkle'], outline='')

    def _update_progress_loop(self):
        if self.current_song:
            el = self.elapsed()
            frac = (el % 60.0) / 60.0 if self.song_length <= 0 else min(1.0, el / self.song_length)
            self.progress.set(frac)
            self._draw_progress()
        self.after(100, self._update_progress_loop)

    def _click_seek(self, event):
        if not self.current_song: return
        target = (event.x / int(self.progress_bar['width'])) * (self.song_length if self.song_length > 0 else 60.0)
        self.play_from(target)

    def load_favorites(self):
        if os.path.exists(FAVORITES_FILE):
            try:
                with open(FAVORITES_FILE, 'r', encoding='utf-8') as f:
                    return set(json.load(f))
            except:
                return set()
        return set()

    def save_favorites(self):
        try:
            with open(FAVORITES_FILE, 'w', encoding='utf-8') as f:
                json.dump(list(self.favorites), f, ensure_ascii=False, indent=2)
        except Exception as e:
            messagebox.showerror('Oops!', f'Cannot save favorites: {e}')

if __name__ == '__main__':
    app = UltraCuteMusicPlayer()
    app.mainloop()